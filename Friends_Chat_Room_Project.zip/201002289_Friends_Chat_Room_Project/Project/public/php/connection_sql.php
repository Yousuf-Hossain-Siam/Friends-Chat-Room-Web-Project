<?php

$id = $_POST['id'];
$password = $_POST['password'];

$con = new mysqli("localhost","root","" ,"Friends_Chat_Room");
if($con ->connect_error){
    die("Failed to connect: " .$con->connect_error);
}else{
    $stmt = $con->prepare("select * from login where id =?");
    $stmt->bind_param("s",$id);
    $stmt->execute();
    $stmt_result = $stmt->get_result();
    if($stmt_result -> num_rows > 0){
        $data = $stmt_result->fetch_assoc();
        if ($data['password'] === $password) {
            header("Location: http://localhost:3000/");
        } else{
           /// header("Location: wrongpass.html");
        }
    }else{
        header("Location: http://localhost/201002289_Friends_Chat_Room_Project/Project/public/wrongpass.html");
    }
}

?>
